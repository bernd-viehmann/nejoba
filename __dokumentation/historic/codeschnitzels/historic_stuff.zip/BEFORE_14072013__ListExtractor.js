﻿// ========================
//   List Extractor Class 
// ========================
//
//   The Class is the client-entrance for the data. it handles the communication to the server-data-source
//   and stores the received itmes in a global array.
//
//   this class is the data-container for the client. it also handles the pagging.
//
//  when the class is initialyzed we gave the number of itmes and size of a page that should be displayed once
//  the init-methode initExtractor loads the needed number of items from the server and creates the pages-array
//  
//  later with the function getPageBefore or getPageAfter you can switch throug the available data 
//  when the function reaches the bound it appends the nextpart of server-data 
//
//  GLOBAL.Items[]    : the array with the received data. it is global member of the document and not 
//                      member of the class.
//
// IMPORTANT: The server sends his data-array backwards. so the Pages-array starts at the end of data.
//
//
//
//
//
//        -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  
//    attributes :
//        -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  
//
//          MainArraySize       : the amount of data-items in the global item-array
//
//          PageSize            : the size of a single page. A page is the part of the main-array that will be displayed. this attribute is set 
//                                ba the consumer. for a map we can have thousands, for a list we may have 50 items displayed once.
//        
//          PageStartIdx        : the index of the first item currently displayed. it is the index in the array, not the db-id
//
//          PageEndIdx          : the last Array-Index of a page
//
//          Pages []            : The array contains the start- and end-idx. this is used for pagging through the items in the main-array
//
//          LastMongoId         : the last DB-ID that was loaded by the class. null for starting (map was just loaded)
//
//
//
//
//
//
//
//
//
//
//
//
// 

//
//
//        -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  
//    member-functions :
//        -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  
//
//        initExtractor     initializes the members of the class
//
//        loadFromServer    get data via jQuery-ajax-call from the server.
//                          the function sends a request to the server and overwrites the existing array.
//                          later the array can be extended to have all received data available on the client
//
//        getPageToDisplay  the function is used to send a portition of data to the displaying-class
//                          the consuming-class (MapProjector or ListCreator) must know what page has to be called
//
//
//



// *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *
// *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *
// *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *


Items = []                                                  // the items received from server are stored in this array
/*
 *  ListExtractor
 *
 *  this class gets the data from the itam-app-cache with java-calls. it stores the 
 *  items in an array and is responsible for the paging of the received itms.
 *  
 */
function ListExtractor( ) {
    try {
        this.UrlCache = '../wbf_activemap/dataSource__cache.aspx'       // source for items from the cache
        this.UrlMongo = '../wbf_activemap/dataSource__mongo.aspx'       // source for items from the database

        this.FirstItemId    = null;             // mongo-id of the first (smallest value) item in the local array 
        this.LastItemId     = null;             // mongo-id of the last  (biggest  value) item in the local array 
        this.Direction      = null;             // dearch direction can be forward or backward

        this.LastMongoId = null;                // the last ID we have loaded from the database. the items in the 
                                                // datatable are loaded backwards. so after a load the pointer points to 
                                                // DataTable-Length - this.amount.

        /*
         * the kickstarter for initialyzing all vars and stuff
         *
         */
        this.initExtractor = function ( itemType, amnt, pgLn ) {
            try {
                this.itemType   = typeof this.itemType !== 'undefined' ? itemType : 'map';          // if not defined set the amount of items that should be loaded into the global array Items
                this.amount     = typeof this.amount   !== 'undefined' ? amnt : 2500;               // if not defined set the amount of items that should be loaded into the global array Items
                this.pageLen    = typeof this.pageLen  !== 'undefined' ? pgLn : 250;                // number of markers that are shown once on the map

                // console.log('initExtractor was called : attribute-values ITEM_TYPE ' + String( this.itemType ) + ' AMOUNT: ' + String( this.amount ) + ' PAGE_LENGTH: ' + String( this.pageLen ));
            }
            catch (err) {
                txt = "There was an error in the MtrxMngr.initItemArray\n\n";
                txt += "Error description: " + err.message + "\n------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
                // console.log(txt);
            }
        } // init-extractor ends here

        // *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  
        // *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  
        // *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  

        /*
        * the load_From_Server func. makes the ajax-call to the server to receive all the stuff
        *
        */
        this.loadFromServer = function () {
            try {
                // console.log('ListExtractor.loadFromServer was called');

                // description of the URL-PARAMETER for loading webform behind this.UrlCache
                //
                // 'http://localhost:7258/njb_2/wbf_topic/mapTwo_dataSource.aspx?loc=DE%7C41836&tags=world&srchMd=OR'
                //
                //  amount      : the number of items that should be send by the datasource
                //  lastdbid    : the last database-id that was received by the client. data-source webform 
                //                should start here.
                //  loc         : the geo-location as sting like "de|41836". if only "de|" is given all german 
                //                results are send to the client from data-source
                //  tags        : the tags we are locking for. list is comma-seperated
                //  srchMd      : OR means display all items with any tag; AND menas display only tags 
                //                that are labeled with all keywords
                //  startdate   : a string-coded date-object to define when the event starts
                //  enddate     : a string-representation of the end of the event
                //

                // url must be build from the given search-parameters

                //this.UrlCache = this.UrlCache + '?loc=DE|41836&tags=world&srchMd=OR&wurst=kaese&zitrone=poline&amount=1000';

                $.getJSON(this.UrlCache, function (jsonObj) {

                    // receive the data-items : {}["items"]
                    var temp = [];
                    $.each(jsonObj.items, function (idx, data) {
                        temp.push(data)
                        // console.log('item added : ' + idx);
                    });
                    temp.reverse();
                    $.each(temp, function (i, newDataItem) {
                        Items.push(newDataItem);
                        // console.log('item ' + i + ' - ' + newDataItem);
                    });

                    // todo: receive the map-configuration lat,lon,zoom {}["mapcnf"]

                    // display the markers on the map
                    mpPrj.displayAllItems();
                });


                return;
            }
            catch (err) {
                txt = "There was an error in the MtrxMngr.initItemArray\n\n";
                txt += "Error description: " + err.message + "\n------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
                // console.log(txt);
            }
        }            // load-From-Server ends here













        /*
        * the buildUrlParams func. gets the needed parameters to call the data-source webform
        *
        */
        this.buildUrlParams = function () {
            try {
                // console.log('ListExtractor.buildUrlParams was called');

                // description of the URL-PARAMETER for loading webform behind this.UrlCache
                //
                // 'http://localhost:7258/njb_2/wbf_topic/mapTwo_dataSource.aspx?loc=DE%7C41836&tags=world&srchMd=OR'
                //
                //  amount      : the number of items that should be send by the datasource
                //  lastdbid    : the last database-id that was received by the client. data-source webform 
                //                should start here.
                //  loc         : the geo-location as sting like "de|41836". if only "de|" is given all german 
                //                results are send to the client from data-source
                //  tags        : the tags we are locking for. list is comma-seperated
                //  srchMd      : OR means display all items with any tag; AND menas display only tags 
                //                that are labeled with all keywords
                //  startdate   : a string-coded date-object to define when the event starts
                //  enddate     : a string-representation of the end of the event
                //
                var paramObj = {};
                paramObj["amount"] = this.amount;
                //paramObj["lastdbid"] = Items[Items.length-1]['_id'];
                paramObj["loc"] = $('CoPlaBottom_sel_country').val() + '|' + $('CoPlaBottom_txbx_postCode').text();
                paramObj["tags"] = $('CoPlaBottom_txbx_hashtag').text();
                paramObj["srchMd"] = 'OR';
                paramObj["startdate"] = $('CoPlaBottom_txbx_timeFrom').text();
                paramObj["enddate"] = $('CoPlaBottom_txbx_timeTo').text();

                // for (var name in paramObj) { console.log('Param  : ' + name + ' ;Value : ' + paramObj[name]); }

                return;
            }
            catch (err) {
                txt = "There was an error in the MtrxMngr.buildUrlParams\n\n";
                txt += "Error description: " + err.message + "\n------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
                // console.log(txt);
            }
        }                // load-From-Server ends here




        // *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  
        // *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  
        // *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  

        /*
        * the get_Page_To_Display func. sends a part of the received data to the display-class
        *
        *
        */
        this.getItemsToDisplay  = function ( pageIdx ) {
            try {
                // console.log('getItemsToDisplay');
                return;
            }
            catch (err) {
                txt = "There was an error in the MtrxMngr.getPageToDisplay\n\n";
                txt += "Error description: " + err.message + "\n------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
                // console.log(txt);
            }
        }  // load-From-Server ends here

        this.initExtractor();
    }

    /*
     *
     *  main class exception-handler
     *
     */
    catch (err) {
        txt = "There was an error in the ListExtractor \n\n";
        txt += "Error description: " + err.message + "\n------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
        // console.log(txt);
    }
};

