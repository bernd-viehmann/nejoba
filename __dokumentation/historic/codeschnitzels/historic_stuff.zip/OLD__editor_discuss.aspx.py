#  
# editor_discuss.aspx.py 
#  
# the webform is used for adding a new article to a discussion-thread
#  
#
#  03.10.2012   bevie    initial realese
#  
import System.DateTime
import System.Drawing.Color
import System.Text
import System.Guid
import traceback                    # for better exception understanding
import re                           # for finding the taggs
import mongoDbMgr                   # father : the acces to the database

from srvcs.ctrl_ItemClasses import *
tool = ItemMngr( Page )

# ------------------------------------------------------------------------------------------------------------------------------------------------##__aspn.net ------------------------------------------------
# ***********************************************************************************************************************************************
# Page_Load        : initializer of the webpage
#
# 18.03.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def Page_Load(sender, e):
    try:
        if( not Page.IsPostBack ):
            # user must be logged in
            tool.usrDt.checkUserRigths(Page, 'free')

            # get the _objectDetailID from the DataTable
            mongoId = Page.Request.QueryString['item'] 
            Page.ViewState['MongoID'] = mongoId
            
            #renderThreat()
            #   r e p l a c e m e n t
            getDiscussion()

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())


# ------------------------------------------------------------------------------------------------------------------------------------------------##__handler ------------------------------------------------
# ***********************************************************************************************************************************************
# usrLoggedIn      : called after user succesfully logged in
#
# 18.11.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def HndlrButtonClick(sender, e):
    try:
        if sender.ID == 'btnComment':
            mongoId = Page.Request.QueryString['item'] 
            tool.saveItem( 'MMBR_COMMENT', mongoId, None )

            # hide editor
            tool.gtCtl('divEditArea').Visible = False
            tool.gtCtl('divApprovedMsg').Visible = True

            #renderThreat()
            #   r e p l a c e m e n t
            getDiscussion()

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())



# ***********************************************************************************************************************************************
# getNegotiation  : called after user succesfully logged in
#
# 18.11.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def getDiscussion():
    try:
        # negotiations are user_dependend : 
        # a user can only have ONE offer-discussion-thread for a given announce
        # webform is called with the root_element_id: get the header_item for this user
        rootId = Page.ViewState['MongoID'].ToString()
        root = tool.itemTbl.Rows.Find( rootId )
        userGUID = tool.usrDt.getItem('GUID').ToString()
        headerType = tool.objectTypes.index('HEAD_COMMENT')

        # get the header-idx
        slctStr = "_rootElemGUID = '" + root['_rootElemGUID'].ToString() + "' AND _creatorGUID = '" + userGUID.ToString() + "' AND objectType = " + str(headerType)
        tool.log.w2lgDvlp('offer_editor.getNegotiation -> ' + slctStr )
        head = tool.itemTbl.Select( slctStr )

        # if there is no thread available just display the details of the root_element
        output = ''
        if len(head) == 0:
            output = tool.displayItem( rootId )
        else:
            rslt = head[0]
            output = tool.getHtmlOfThread( rslt['_id'] )

        tool.ui.getCtrlTree( Page.Master )
        canvas = tool.ui.findCtrl( Page, 'divShowMain')
        canvas.InnerHtml = output

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())


