#  
#  user_discussions.aspx
#  
#  shows discussions of the loogggged in user
#  
#  
#  
from System.Data import *
import System.Collections
from System.Web.Configuration import *
import clr
import traceback                    # for better exception understanding
import mongoDbMgr                   # father : the acces to the database


tool = mongoDbMgr.mongoMgr(Page)

# ***********************************************************************************************************************************************
# Page_Load        : initializer of the webpage
#
# 18.03.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def Page_Load(sender, e):
    try:
        if( not Page.IsPostBack ):
            # user must be logged in
            #tool.usrDt.checkUserRigths(Page, 'free')

            # display the announces of the user
            ShowUserDiscussions()

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())



# ***********************************************************************************************************************************************
# GetList       : create a list of all annonces the user made and send them to the repeater
#
# 01.01.2013  - bervie -     initial realese
# ***********************************************************************************************************************************************
def ShowUserDiscussions():
    try:
        userGUID = tool.usrDt.getItem('GUID').ToString()
        objTypConfig    = WebConfigurationManager.AppSettings['objectTypes']
        strngSeperator  = WebConfigurationManager.AppSettings['stringSeperator']
        objectTypes = objTypConfig.split(strngSeperator)
        objectType = objectTypes.index('HEAD_COMMENT')

        # filter for offer-headers and copy the rootElementID to get the detail-data
        itemTable = tool.appCch.dtSt.Tables['items']
        slctStr = "_creatorGUID = '" + userGUID.ToString() + "' AND objectType = " + str(objectType)
        itemTable.DefaultView.RowFilter = slctStr;
        filteredView = itemTable.DefaultView

        rowElemGuids = []
        for row in filteredView:
            rootGuid   = row['_rootElemGUID'].ToString()
            #creator    = row['_creatorGUID'].ToString()
            #headerId   = row['_ID'].ToString()
            #objectType = row['objectType'].ToString()
            #tool.logMsg('- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ' )
            #tool.logMsg('ShowUsersOffers : ROOT_ELEMENT_GUID found for users OFFERS  - ' + rootGuid )
            #tool.logMsg('ShowUsersOffers : CREATOR_GUID      found for users OFFERS  - ' + creator )
            #tool.logMsg('ShowUsersOffers : header_ID         found for users OFFERS  - ' + headerId )
            #tool.logMsg('ShowUsersOffers : objectType        found for users OFFERS  - ' + objectType )
            #tool.logMsg('- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ' )
            # load the root_element-id once
            if not rowElemGuids.Contains( rootGuid ):
                rowElemGuids.Add( rootGuid )
                tool.logMsg('ShowUsersOffers : rootGuid added to rowElemGuids  - ' + rootGuid )

        commentsTable = DataTable()
        commentsTable = itemTable.Clone()

        objectType = objectTypes.index('ROOT_JOB')
        for itmGuid in rowElemGuids:

            slctStr = "_rootElemGUID = '" + itmGuid + "' AND objectType = " + str(objectType)
            itemTable.DefaultView.RowFilter = slctStr;
            filteredView = itemTable.DefaultView

            for itmGuid in filteredView:
                #rows.Add(itmGuid)
                commentsTable.ImportRow(itmGuid.Row)
                tool.logMsg('ShowUsersOffers : root-row added to rowElemGuids  - ' + itmGuid['_ID'] )


        ## 3. bind repeater to data-table
        repeater = tool.gtCtl('repDiscussionsList')
        repeater.DataSource = commentsTable
        repeater.DataBind()

        ## 4. create a list with all db-IDs into the viewstate
        ##    will be used as parameter for the webforms that are called
        ##    from the joblist
        idList = System.Collections.ArrayList()
        rows = commentsTable.Rows
        for itm in rows:
            idList.Add( itm[0].ToString() )

        Page.ViewState['IdList'] = idList

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())



# ***********************************************************************************************************************************************
# HndlrReactionClick : handler for buttons that initiate a reaction on a given announcement
#
# 18.03.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def HndlrReactionClick(sender, e):
    try:
        # get the needed informations from the ID by seperating string by '_'. 
        # the DB-ID of the data-item is stored on place [3]
        clntIdComponents = sender.ClientID.ToString().split('_')
        if len(clntIdComponents) != 4: return
        swtchStr = clntIdComponents[2][3:]

        tool.logMsg('HndlrReactionClick : Clicked Item-ID ' + str( swtchStr ) )

        url = ''
        tblId  = clntIdComponents[3]

        # the webforms are called with the detail-id (item.announcment for example)
        # 
        idList = Page.ViewState['IdList']
        itemId = str(idList[int(tblId.ToString())])

        tool.logMsg('HndlrReactionClick : Clicked Item-ID ' + str( swtchStr ) + ' - ' + str( itemId ) )

        if   swtchStr == 'View': url = "show_details.aspx?item=" + itemId
        elif swtchStr == 'Disc': url = "editor_discuss.aspx?item=" + itemId
        elif swtchStr == 'Rprt': url = "editor_report.aspx?item=" + itemId
        elif swtchStr == 'Offr': url = "editor_offer.aspx?item=" + itemId

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())

    Response.Redirect(url)


