#  
#
#  
#  
#  
#  
#  
#
#  
from System.Web.Configuration import *


# ***********************************************************************************************************************************************
# Page_Load        : initializer of the webpage
#
# 18.03.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def Page_Load(sender, e):
    pass


# ------------------------------------------------------------------------------------------------------------------------------------------------##__handler ------------------------------------------------
# ***********************************************************************************************************************************************
# HndlrButtonClick    : handler for button-click-events. chose button by ID
#
# 18.11.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def HndlrButtonClick(sender, e):
    try:
        if sender.ID == 'btnCreate':
            tool.createUser()

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())
        return

    if tool.confirmUrl != None :
        tool.log.w2lgDvlp('CreateUser redirects to : ' +  unicode(tool.confirmUrl) )
        Response.Redirect(tool.confirmUrl)

