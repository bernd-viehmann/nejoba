#  
# editor.aspx.py 
#  
# the webform is used for creating new job offers for the community. user can define the location, the typ of the job and the time of action
#  
#
#  03.10.2012   bevie    initial realese
#  
 
import System.DateTime
import System.Drawing.Color
import System.Guid
from System.Web.Configuration import *
from System import UriPartial

import traceback                    # for better exception understanding
import re                           # for finding the taggs

from srvcs.ctrl_ItemClasses import ItemMngr

tool = ItemMngr( Page )

# import mongoDbMgr                   # father : the acces to the database
# tool = mongoDbMgr.mongoMgr(Page);

# ------------------------------------------------------------------------------------------------------------------------------------------------##__aspn.net ------------------------------------------------
# ***********************************************************************************************************************************************
# Page_Load        : initializer of the webpage
#
# 28.03.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def Page_Load(sender, e):
    try:
        if( not Page.IsPostBack ):
            pass
            #mongoId = Page.Request.QueryString['item'] 
            #Page.ViewState['MongoID'] = mongoId     # used to call external sides from this editor

            #canvas = tool.ui.findCtrl( Page, 'divShowMain')
            #canvas.InnerHtml = tool.loadItem(mongoId)['html']

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())


# ------------------------------------------------------------------------------------------------------------------------------------------------##__handler ------------------------------------------------
# ***********************************************************************************************************************************************
# HndlrReactionClick : handler for buttons to redirect to a webform with different functionality (am i brainfucking ?!?)
#
# 18.03.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def HndlrReactionClick(sender, e):
    try:
        # get the needed informations from the ID by seperating string by '_'. 
        clntIdComponents = sender.ClientID.ToString().split('_')
        swtchStr = clntIdComponents[1][3:]

        urlNext = None

        itemId = Page.ViewState['MongoID']
        if   swtchStr == 'List': 
            urlNext = WebConfigurationManager.AppSettings["listJobPage"]
        elif swtchStr == 'Disc': 
            urlNext = WebConfigurationManager.AppSettings["editDiscussPg"] + "?item=" + itemId
        elif swtchStr == 'Rprt': 
            urlNext = WebConfigurationManager.AppSettings["editReportPg"] + "?item=" + itemId
        elif swtchStr == 'Offr': 
            urlNext = WebConfigurationManager.AppSettings["editOfferPg"] + "?item=" + itemId
        elif swtchStr == 'Start': 
            StartProcessing()
        if urlNext != None :
            nextUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority)
            nextUrl += urlNext
            tool.log.w2lgDvlp('show_details.aspx.py jump-url in click-handler : ' + nextUrl)

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())
        return

    if urlNext != None :
        Response.Redirect(nextUrl)



# ***********************************************************************************************************************************************
# HndlrReactionClick : handler for buttons to redirect to a webform with different functionality (am i brainfucking ?!?)
#
# 18.03.2012  - bervie -     initial realese
# ***********************************************************************************************************************************************
def StartProcessing():
    try:
        tool.ui.getCtrlTree( Page.Master )
        index = tool.ui.getCtrl('tbxIndex').Text
        canvas = tool.ui.findCtrl( Page, 'divShowMain')

        threadHtml = tool.getHtmlOfThread(index)

        canvas.InnerHtml = threadHtml

    except Exception,e:
        tool.log.w2lgError(traceback.format_exc())
        return















































































































