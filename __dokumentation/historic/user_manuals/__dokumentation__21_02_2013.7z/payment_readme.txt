pay_pal settings


changeOut.Add('','##@@_header_@@##')
changeOut.Add('','##@@_tarif_@@##')
changeOut.Add('','##@@_price_@@##')
changeOut.Add('','##@@_time_@@##')
changeOut.Add('','##@@_business_@@##')
changeOut.Add('','##@@_currency_code_@@##')
changeOut.Add('','##@@_custom_@@##')
changeOut.Add('','##@@_name_for_billing_@@##')
changeOut.Add('','##@@_item_number_@@##')
changeOut.Add('','##@@_short_price_@@##')
changeOut.Add('','##@@_tax_@@##')
changeOut.Add('','##@@_notify_url_@@##')




Bankleitzahl         bankcode
Kontonummer          accountnumber
Kontoinhaber         accountowner
Betrag               amount
Verwendungszweck 1   designated_one
Verwendungszweck 2   designated_two



txbx_bankcode
txbx_accountnumber
txbx_accountowner
txbx_amount
txbx_designated_one
txbx_designated_two


bankcode
accountnumber
accountowner
amount
designated_one
designated_two








